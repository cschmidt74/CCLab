#include "parser.hpp"

int main(int argc, char const *argv[]){
	return yyparse();
}