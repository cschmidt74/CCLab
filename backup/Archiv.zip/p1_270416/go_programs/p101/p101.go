//Smallest possible go program

package main

func main(){
}
